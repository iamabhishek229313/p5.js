let bubbles =[] ;

function setup (){

  createCanvas (600,400);
  for (let i =0 ; i < 10 ; i++){
    let x = random (width);
    let y = random (height);
    let r = random (20,50);
    bubbles[i] = new Bubble (x,y,r);
  }
}
function  draw (){
  background (0);
  for (b of bubbles){
if(b.rollover(mouseX,mouseY)){
  b.colorchange(120);
}else{
  b.colorchange(0);
}
  b.show();
  b.move();
  }

}
function mousePressed (){
  //while we have to referance any particular object in an array we can,t use for of loop .
       for(let i = 0 ; i < bubbles.length ; i++){
                 if(bubbles[i].rollover(mouseX,mouseY)){
                   bubbles.splice(i ,1);
                 }
    }
}


//Use generalised form as x , y and r !
class Bubble {
 constructor (a,b,c){
   this.x = a ;
   this.y = b ;
   this.r = c ;
   this.brightness = 0 ;
 }
move(){
  this.x = this.x + random (-1,1);
  this.y = this.y + random (-1,1);
}

intersects (other){
   let p = dist (this.x ,this.y , other.x , other.y);
   return (p<this.r + other.r);
 }

 rollover (pofx,pofy){
   let d = dist(pofx,pofy,this.x,this.y);
   if (d<this.r){
     return true ;
   }else{
     return false ;
   }
 }
 colorchange (bright){
   this.brightness = bright ;
 }

show (){

   fill (this.brightness);
  stroke(255);
  strokeWeight (2);
 ellipse (this.x ,this.y, this.r * 2);

   }
}
